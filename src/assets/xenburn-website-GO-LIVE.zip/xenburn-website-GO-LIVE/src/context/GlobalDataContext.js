import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import { ethers } from 'ethers';
import { useWallet } from './WalletContext';
// Import necessary addresses from constants
import {
  XEN_ADDRESS,
  XBURN_TOKEN_ADDRESS, // Assuming this is the XBURN token address
  XBURN_NFT_ADDRESS,
  XBURN_MINTER_ADDRESS,
  XBURN_XEN_LP_ADDRESS // Using the correct LP constant
} from '../constants/addresses';

const GlobalDataContext = createContext();

// Constants for pagination
const PER_PAGE = 10;

// Add ERC20 ABI
const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function approve(address, uint256) returns (bool)',
  'function allowance(address, address) view returns (uint256)',
  'function transfer(address, uint256) returns (bool)',
  'function totalSupply() view returns (uint256)'
];

// REMOVED Hardcoded Sepolia Addresses
// const CONTRACTS = { ... };

export const GlobalDataProvider = ({ children }) => {
  const { 
    account, 
    provider, 
    ethBalance, 
    xenBalance, 
    xburnBalance, 
    xenBalanceRaw, 
    xburnBalanceRaw, 
    xenApprovalRaw, 
    xburnApprovalRaw 
  } = useWallet();
  
  // NFT data state
  const [nfts, setNfts] = useState([]);
  const [loadingNFTs, setLoadingNFTs] = useState(false);
  const [nftError, setNftError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalNFTs, setTotalNFTs] = useState(0);

  // Stats state
  const [stats, setStats] = useState({
    loading: false,
    error: null,
    data: {
      totalXenBurned: '0',
      totalXburnMinted: '0',
      totalXburnBurned: '0',
      globalBurnRank: '0',
      userXenBurned: '0',
      userXburnMinted: '0',
      userXburnBurned: '0'
    },
    lastFetched: 0
  });

  // Add state for DexScreener data
  const [xenPrice, setXenPrice] = useState('0');
  const [xburnPrice, setXburnPrice] = useState('0');
  const [poolTvl, setPoolTvl] = useState('0');
  const [loadingPrices, setLoadingPrices] = useState(false);
  const [priceError, setPriceError] = useState(null);

  // --- State for External Stats from JSON ---
  const [externalStats, setExternalStats] = useState({
    loading: false,
    error: null,
    data: null, // Store the entire JSON object here
    lastFetched: 0
  });

  // --- Debounce Timestamps using useRef ---
  const lastNftFetchTime = useRef(0);
  const MIN_NFT_FETCH_INTERVAL = 5000; 
  const lastStatsFetchTime = useRef(0);
  const MIN_STATS_FETCH_INTERVAL = 10000;
  const lastPriceFetchTime = useRef(0);
  const MIN_PRICE_FETCH_INTERVAL = 30000; // Fetch prices less often (e.g., 30 seconds)
  const lastExternalStatsFetchTime = useRef(0);
  const MIN_EXTERNAL_STATS_FETCH_INTERVAL = 60000; // Fetch external stats every minute

  // --- Contract Instance Getters (useCallback) ---
  const xenftContract = useCallback(() => {
    if (!provider) return null;
    console.log("Initializing XENFT contract at", XBURN_NFT_ADDRESS); // Use Constant
    
    const XENFT_CONTRACT_ABI = [
      "function tokenOfOwnerByIndex(address owner, uint256 index) external view returns (uint256)",
      "function ownerOf(uint256 tokenId) external view returns (address)",
      "function tokenURI(uint256 tokenId) external view returns (string memory)",
      "function getLockDetails(uint256 tokenId) external view returns (uint256 xenAmount, uint256 maturityTs, uint256 ampSnapshot, uint256 termDays, bool claimed, uint256 rewardAmount, uint256 baseMint, address owner)",
      "function balanceOf(address owner) external view returns (uint256)"
    ];
    
    const contract = new ethers.Contract(
      XBURN_NFT_ADDRESS, // Use Constant
      XENFT_CONTRACT_ABI, 
      provider.getSigner ? provider.getSigner() : provider
    );
    
    window.xenftContract = contract; // Still potentially useful for debugging
    return contract;
  }, [provider]);

  const xenftBurnContract = useCallback(() => {
    if (!provider) return null;
    
    try {
      console.log("Initializing XBurnMinter contract at", XBURN_MINTER_ADDRESS); // Use Constant
      const abi = [
        "function claimLockedXBURN(uint256 tokenId) external",
        "function emergencyEnd(uint256 tokenId) external",
        "function getTokenStats(uint256 tokenId) external view returns (uint256 xenAmount, uint256 baseMint, uint256 rewardAmount, uint256 maturityTs, bool isClaimable, bool isClaimed)",
        "function balanceOf(address owner) external view returns (uint256)",
        "function getUserLocks(address user) external view returns (uint256[])",
        "function getStats(address user) external view returns (uint256 userXenBurnedAmount, uint256 userXburnBurnedAmount, uint256 userXburnBalance, uint256 userBurnPercentage, uint256 globalXenBurned, uint256 globalXburnBurned, uint256 totalXburnSupply, uint256 globalBurnPercentage)",
        "function globalBurnRank() external view returns (uint256)",
        "function getGlobalStats() external view returns (uint256 currentAMP, uint256 daysSinceLaunch, uint256 totalBurnedXEN, uint256 totalMintedXBURN, uint256 ampDecayDaysLeft)"
      ];
      
      return new ethers.Contract(
        XBURN_MINTER_ADDRESS, // Use Constant
        abi,
        provider.getSigner ? provider.getSigner() : provider
      );
    } catch (error) {
      console.error("Error initializing XBurnMinter contract:", error);
      return null;
    }
  }, [provider]);

  const xenContract = useCallback(() => {
    if (!provider) return null;
    console.log("Initializing XEN contract at", XEN_ADDRESS); // Use Constant
    return new ethers.Contract(XEN_ADDRESS, ERC20_ABI, provider); // Use Constant
  }, [provider]);

  const xburnContract = useCallback(() => {
    if (!provider) return null;
    console.log("Initializing XBURN contract at", XBURN_TOKEN_ADDRESS); // Use Constant
    return new ethers.Contract(XBURN_TOKEN_ADDRESS, ERC20_ABI, provider); // Use Constant
  }, [provider]);

  // --- Data Loading Functions ---
  const loadNFTById = useCallback(async (tokenId) => {
    const minterContract = xenftBurnContract();
    const nftContract = xenftContract();
    if (!account || !minterContract || !nftContract || !tokenId) {
      console.log("Load NFT By ID: Skipped, dependencies not ready.");
      return null;
    }

    try {
      console.log("Loading NFT details for token ID", tokenId);
      const baseNftContract = nftContract;
      
      // First check if the user owns this NFT
      try {
        const owner = await baseNftContract.ownerOf(tokenId);
        if (owner.toLowerCase() !== account.toLowerCase()) {
          console.error("User does not own this NFT");
          return null;
        }
      } catch (error) {
        console.error("Error checking NFT ownership:", error);
        return null;
      }
      
      // Get the details for the NFT from the NFT contract
      const details = await baseNftContract.getLockDetails(tokenId);
      console.log("NFT details for", tokenId, ":", details);
      
      // Get additional token stats from the burn contract
      const tokenStats = await minterContract.getTokenStats(tokenId);
      console.log("Token stats for", tokenId, ":", tokenStats);
      
      return {
        tokenId: tokenId.toString(),
        details: {
          xenAmount: details.xenAmount.toString(),
          maturityTs: details.maturityTs.toString(),
          ampSnapshot: details.ampSnapshot.toString(),
          termDays: details.termDays.toString(),
          claimed: details.claimed,
          rewardAmount: details.rewardAmount.toString(),
          baseMint: details.baseMint.toString(),
          owner: details.owner,
          isClaimable: tokenStats.isClaimable
        }
      };
    } catch (error) {
      console.error(`Error loading NFT ${tokenId}:`, error);
      return null;
    }
  }, [account, xenftBurnContract, xenftContract]);

  const loadNFTs = useCallback(async () => {
    // Debounce check using ref
    const now = Date.now();
    if (now - lastNftFetchTime.current < MIN_NFT_FETCH_INTERVAL) {
      console.log('Skipping NFT fetch, last fetch was too recent');
      return;
    }
    lastNftFetchTime.current = now;

    const minterContract = xenftBurnContract();
    const nftContract = xenftContract();
    if (!account || !minterContract || !nftContract) {
      console.log("Load NFTs: Skipped, dependencies not ready.");
      return;
    }

    setLoadingNFTs(true);
    setNftError(null);

    try {
      console.log("Loading NFTs for account", account, "page", currentPage);
      const baseNftContract = nftContract;
      
      // Get total NFTs for user
      let totalNFTsCount = 0;
      try {
        console.log("Getting NFT balance for account", account);
        const balance = await baseNftContract.balanceOf(account);
        totalNFTsCount = parseInt(balance.toString(), 10);
        console.log("NFT balance:", totalNFTsCount);
        setTotalNFTs(totalNFTsCount);
        setTotalPages(Math.ceil(totalNFTsCount / PER_PAGE) || 1);
      } catch (error) {
        console.error('Error getting NFT balance:', error);
        setNftError('Error getting NFT balance');
        setLoadingNFTs(false);
        return;
      }

      if (totalNFTsCount === 0) {
        console.log("No NFTs found for account", account);
        setNfts([]);
        setLoadingNFTs(false);
        return;
      }

      // Get token IDs directly from the contract
      const tokenIds = [];
      const promises = [];
      
      // Try to get token IDs directly from the contract
      for (let i = 0; i < Math.min(totalNFTsCount, 20); i++) {
        promises.push(
          (async (index) => {
            try {
              const tokenId = await baseNftContract.tokenOfOwnerByIndex(account, index);
              return tokenId.toString();
            } catch (error) {
              console.error(`Error fetching token at index ${index}:`, error);
              return null;
            }
          })(i)
        );
      }
      
      const results = await Promise.all(promises);
      results.forEach(tokenId => {
        if (tokenId !== null) {
          tokenIds.push(tokenId);
        }
      });
      
      console.log("Token IDs:", tokenIds);
      
      if (tokenIds.length === 0) {
        setNftError("Could not retrieve your NFTs. Please try again later.");
        setNfts([]);
        setLoadingNFTs(false);
        return;
      }
      
      // Load details for the first NFT
      try {
        const firstTokenId = tokenIds[0];
        const details = await loadNFTById(firstTokenId);
        
        if (details) {
          const firstNft = {
            ...details,
            allTokenIds: tokenIds // Store all token IDs for the dropdown
          };
          
          setNfts([firstNft]);
        } else {
          setNftError("Error loading NFT details. Please try again later.");
        }
      } catch (error) {
        console.error("Error loading first NFT details:", error);
        setNftError("Error loading NFT details. Please try again later.");
      }
    } catch (error) {
      console.error('Error loading NFTs:', error);
      setNftError(error.message);
    } finally {
      setLoadingNFTs(false);
    }
  }, [account, xenftBurnContract, xenftContract, currentPage, loadNFTById]);

  const loadStats = useCallback(async () => {
    // Debounce check using ref
    const now = Date.now();
    if (now - lastStatsFetchTime.current < MIN_STATS_FETCH_INTERVAL) {
      console.log('Skipping stats fetch, last fetch was too recent');
      return;
    }
    lastStatsFetchTime.current = now;

    const minterContract = xenftBurnContract();
    const baseContract = xenContract();
    if (!account || !provider || !minterContract || !baseContract) {
      console.log("Load Stats: Skipped, dependencies not ready.");
      return;
    }
    
    setStats(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      console.log("Loading stats for account", account, "using minter:", minterContract?.address);
      
      // Declare variables outside the try block
      let statsData = null;
      let globalBurnRank = null;
      let currentAMP = null;
      let daysSinceLaunch = null;
      let totalBurnedXENGlobal = null;
      let totalMintedXBURNGlobal = null;
      let ampDecayDaysLeft = null;

      try {
        console.log("Calling minterContract.getStats...");
        statsData = await minterContract.getStats(account);
        console.log("Raw getStats return:", statsData);

        console.log("Calling minterContract.globalBurnRank...");
        globalBurnRank = await minterContract.globalBurnRank();
        console.log("Raw globalBurnRank return:", globalBurnRank);
        
        console.log("Calling minterContract.getGlobalStats...");
        const globalStatsResult = await minterContract.getGlobalStats(); 
        console.log("Raw getGlobalStats return:", globalStatsResult);

        // Destructure global stats & Assign to variables declared outside
        [currentAMP, daysSinceLaunch, totalBurnedXENGlobal, totalMintedXBURNGlobal, ampDecayDaysLeft] = globalStatsResult;

      } catch (contractCallError) {
        console.error("ERROR during stats contract calls:", contractCallError);
        setStats(prev => ({ ...prev, loading: false, error: `Stats contract call failed: ${contractCallError.message}` }));
        return; // Stop execution if essential stats calls fail
      }
      
      let xenSupply = '0';
      try {
        console.log("Checking baseContract before calling totalSupply:", baseContract);
        // Explicitly check if the function exists on the instance
        if (baseContract && typeof baseContract.totalSupply === 'function') {
          xenSupply = await baseContract.totalSupply(); 
          console.log("XEN Total Supply:", ethers.utils.formatUnits(xenSupply, 18));
        } else {
           console.error("baseContract.totalSupply is NOT a function or baseContract is invalid.", baseContract);
           // Optionally set an error state or return default value
        }
      } catch (error) {
        console.error("Error fetching XEN supply:", error);
      }
      
      // Get LP pool data
      let xenInPool = '0';
      let xburnInPool = '0';
      
      try {
        // Removed factory/getPair logic - Directly use the known LP address
        console.log("Using provided LP Pair address:", XBURN_XEN_LP_ADDRESS);
        
        if (XBURN_XEN_LP_ADDRESS && XBURN_XEN_LP_ADDRESS !== ethers.constants.AddressZero) {
          // LP Pair ABI (Keep ABI as is)
          const lpPairAbi = [
            "function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)",
            "function token0() external view returns (address)"
          ];
          
          // Create LP pair contract instance using the provided constant
          const lpPairContract = new ethers.Contract(XBURN_XEN_LP_ADDRESS, lpPairAbi, provider);
          
          // Get token order in the pair
          const token0 = await lpPairContract.token0();
          console.log("Token0:", token0);
          
          // Get reserves
          const reserves = await lpPairContract.getReserves();
          console.log("Reserves:", reserves);
          
          // Determine which reserve is XEN and which is XBURN using imported constants
          if (token0.toLowerCase() === XEN_ADDRESS.toLowerCase()) {
            xenInPool = reserves.reserve0;
            xburnInPool = reserves.reserve1;
          } else {
            xenInPool = reserves.reserve1;
            xburnInPool = reserves.reserve0;
          }
          
          console.log("XEN in pool:", ethers.utils.formatUnits(xenInPool, 18));
          console.log("XBURN in pool:", ethers.utils.formatUnits(xburnInPool, 18));
        } else {
          console.log("LP Pair address is zero or not provided.");
        }
      } catch (error) {
        console.error("Error fetching LP pool data:", error);
      }
      
      // --- Construct the final stats object --- 
      const finalStatsData = {
        totalXenBurned: ethers.utils.formatUnits(totalBurnedXENGlobal || '0', 18),
        totalXburnMinted: ethers.utils.formatUnits(totalMintedXBURNGlobal || '0', 18),
        totalXburnBurned: ethers.utils.formatUnits(statsData?.globalXburnBurned || '0', 18),
        globalBurnPercentage: ethers.utils.formatUnits(statsData?.globalBurnPercentage || '0', 18),
        currentAMP: currentAMP ? currentAMP.toString() : '0',
        globalBurnRank: globalBurnRank?.toString() || '0',
        userXenBurned: ethers.utils.formatUnits(statsData?.userXenBurnedAmount || '0', 18),
        userXburnMinted: '0',
        userXburnBurned: ethers.utils.formatUnits(statsData?.userXburnBurnedAmount || '0', 18),
        xenSupply: ethers.utils.formatUnits(xenSupply || '0', 18),
        xenInPool: ethers.utils.formatUnits(xenInPool || '0', 18),
        xburnInPool: ethers.utils.formatUnits(xburnInPool || '0', 18),
        daysSinceLaunch: daysSinceLaunch ? daysSinceLaunch.toString() : '0',
        ampDecayDaysLeft: ampDecayDaysLeft ? ampDecayDaysLeft.toString() : '0',
      };

      console.log("Stats loaded:", finalStatsData); // Log the object being set
      
      setStats({
        loading: false,
        error: null,
        data: finalStatsData,
        lastFetched: Date.now()
      });
    } catch (error) {
      console.error('Error loading stats:', error);
      setStats(prev => ({
        ...prev,
        loading: false,
        error: error.message
      }));
    }
  }, [account, provider, xenftBurnContract, xenContract]);

  // --- DexScreener Data Loading Function ---
  const fetchDexScreenerData = useCallback(async () => {
    // Debounce
    const now = Date.now();
    if (now - lastPriceFetchTime.current < MIN_PRICE_FETCH_INTERVAL) {
      console.log('Skipping price fetch, last fetch too recent');
      return;
    }
    lastPriceFetchTime.current = now;

    setLoadingPrices(true);
    setPriceError(null);

    const cbxenPairAddress = "0xe28f5637d009732259fcbb5cea23488a411a5ead"; // WETH/cbXEN? 
    const xburnPairAddress = "0x93e39bd6854d960a0c4f5b592381bb8356a2d725"; // cbXEN/XBURN
    const dexscreenerApiBase = "https://api.dexscreener.com/latest/dex/pairs/base/";

    try {
      console.log("Fetching DexScreener data...");
      const [cbxenResponse, xburnResponse] = await Promise.all([
        fetch(`${dexscreenerApiBase}${cbxenPairAddress}`),
        fetch(`${dexscreenerApiBase}${xburnPairAddress}`)
      ]);

      if (!cbxenResponse.ok || !xburnResponse.ok) {
        console.error('Failed to fetch from DexScreener', { 
          cbxenStatus: cbxenResponse.status, 
          xburnStatus: xburnResponse.status 
        });
        throw new Error('Failed to fetch pair data from DexScreener');
      }

      const cbxenData = await cbxenResponse.json();
      const xburnData = await xburnResponse.json();

      // --- Process cbXEN Pair --- 
      if (cbxenData.pair) {
          // Assuming cbXEN is the baseToken in this pair - needs verification
          // If cbXEN is quoteToken, logic needs adjustment
          if (cbxenData.pair.baseToken?.address?.toLowerCase() === XEN_ADDRESS.toLowerCase()) {
             setXenPrice(cbxenData.pair.priceUsd || '0');
             console.log("Fetched cbXEN Price (as base):", cbxenData.pair.priceUsd);
          } else if (cbxenData.pair.quoteToken?.address?.toLowerCase() === XEN_ADDRESS.toLowerCase()) {
             // If cbXEN is quote, priceUsd is price of base in terms of quote.
             // We need 1 / price of quote in terms of base. 
             // Dexscreener usually prices base in terms of quote. Check API structure.
             // For now, log a warning and keep price 0 until structure is confirmed.
             console.warn("cbXEN is quote token in pair", cbxenPairAddress, "- Price calculation needs review.");
             setXenPrice('0'); // Needs verification
          } else {
             console.warn("cbXEN address not found in base/quote token for pair", cbxenPairAddress);
             setXenPrice('0');
          }
      } else {
         console.warn("No pair data found for cbXEN address:", cbxenPairAddress);
         setXenPrice('0');
      }

      // --- Process XBURN/cbXEN Pair --- 
      if (xburnData.pair) {
          // Determine XBURN price based on which token is base
          if (xburnData.pair.baseToken?.address?.toLowerCase() === XBURN_TOKEN_ADDRESS.toLowerCase()) {
             setXburnPrice(xburnData.pair.priceUsd || '0');
             console.log("Fetched XBURN Price (as base):", xburnData.pair.priceUsd);
          } else if (xburnData.pair.quoteToken?.address?.toLowerCase() === XBURN_TOKEN_ADDRESS.toLowerCase()) {
             // PriceUsd is likely price of the BASE (cbXEN) in terms of QUOTE (XBURN)
             // To get price of XBURN, we need price of quote in terms of base (cbXEN)
             // This might involve inverting or using priceNative if available and stable
             // For now, log warning, keep price 0
             console.warn("XBURN is quote token in pair", xburnPairAddress, "- Price calculation needs review.");
             setXburnPrice('0'); // Needs verification
          } else {
             console.warn("XBURN address not found in base/quote token for pair", xburnPairAddress);
             setXburnPrice('0');
          }
          
          // Get TVL
          setPoolTvl(xburnData.pair.liquidity?.usd || '0');
          console.log("Fetched Pool TVL:", xburnData.pair.liquidity?.usd);
      } else {
         console.warn("No pair data found for XBURN address:", xburnPairAddress);
         setXburnPrice('0');
         setPoolTvl('0');
      }

    } catch (error) {
      console.error("Error fetching DexScreener data:", error);
      setPriceError(error.message);
      // Keep old prices on error? Or set to 0?
      // setXenPrice('0'); 
      // setXburnPrice('0');
      // setPoolTvl('0');
    } finally {
      setLoadingPrices(false);
    }
  }, []); // No dependencies needed for pure fetch logic

  // --- Fetch External Stats from GitHub Action JSON ---
  const fetchExternalStats = useCallback(async () => {
    const now = Date.now();
    if (now - lastExternalStatsFetchTime.current < MIN_EXTERNAL_STATS_FETCH_INTERVAL) {
      console.log('Skipping external stats fetch, last fetch too recent');
      return;
    }
    lastExternalStatsFetchTime.current = now;

    setExternalStats(prev => ({ ...prev, loading: true, error: null }));
    const url = "https://raw.githubusercontent.com/TreeCityWes/XBURN-STATS/refs/heads/main/stats.json";
    console.log(`Fetching external stats from: ${url}`);

    try {
      const response = await fetch(url, {
        cache: 'no-cache' // Ensure fresh data
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      console.log("External stats fetched successfully:", data);
      setExternalStats(prev => ({ 
        ...prev, 
        loading: false, 
        data: data, 
        lastFetched: now 
      }));
    } catch (error) {
      console.error('Error fetching external stats:', error);
      setExternalStats(prev => ({ ...prev, loading: false, error: error.message }));
    } 
  }, []);

  // Main Data Loading Effect
  useEffect(() => {
    if (account && provider) { 
      console.log("Account/Provider changed, loading global data for", account);
      loadNFTs(); 
      loadStats();  
      fetchDexScreenerData(); // Call the new function
      fetchExternalStats(); // <--- ADD THIS CALL
    }
    // Add interval polling for prices?
    const priceIntervalId = setInterval(fetchDexScreenerData, MIN_PRICE_FETCH_INTERVAL + 500); // Poll slightly slower than debounce interval
    // Add interval polling for external stats
    const externalStatsIntervalId = setInterval(fetchExternalStats, MIN_EXTERNAL_STATS_FETCH_INTERVAL + 500); // Poll external stats
    
    return () => {
      clearInterval(priceIntervalId);
      clearInterval(externalStatsIntervalId); // Clear interval on cleanup
    };

  }, [account, provider, loadNFTs, loadStats, fetchDexScreenerData, fetchExternalStats]); // <-- Already added here, good. No change needed to array.

  // Claim NFT function
  const claimNFT = useCallback(async (tokenId) => {
    const contract = xenftBurnContract();
    if (!account || !provider || !contract) {
      throw new Error("Wallet not connected or contract not initialized");
    }
    
    try {
      console.log("Claiming NFT", tokenId, "for account", account);
      const signer = provider.getSigner();
      const connectedContract = contract.connect(signer);
      const tx = await connectedContract.claimLockedXBURN(tokenId);
      console.log("Claim transaction sent:", tx.hash);
      await tx.wait();
      console.log("Claim transaction confirmed");
      return true;
    } catch (error) {
      console.error("Error claiming NFT:", error);
      throw error;
    }
  }, [account, provider, xenftBurnContract]);

  // Emergency end NFT function
  const emergencyEndNFT = useCallback(async (tokenId) => {
    const contract = xenftBurnContract();
    if (!account || !provider || !contract) {
      throw new Error("Wallet not connected or contract not initialized");
    }
    
    try {
      console.log("Emergency ending NFT", tokenId, "for account", account);
      const signer = provider.getSigner();
      const connectedContract = contract.connect(signer);
      const tx = await connectedContract.emergencyEnd(tokenId);
      console.log("Emergency end transaction sent:", tx.hash);
      await tx.wait();
      console.log("Emergency end transaction confirmed");
      return true;
    } catch (error) {
      console.error("Error emergency ending NFT:", error);
      throw error;
    }
  }, [account, provider, xenftBurnContract]);

  // Create context value
  const value = {
    nfts,
    loadingNFTs,
    nftError,
    loadNFTs,
    loadNFTById,
    claimNFT,
    emergencyEndNFT,
    currentPage,
    totalPages,
    setCurrentPage,
    totalNFTs,
    xenftContract,
    xenftBurnContract,
    xenContract,
    xburnContract,
    balances: { 
      eth: ethBalance,
      xen: xenBalance,
      xburn: xburnBalance,
      xenRaw: xenBalanceRaw,
      xburnRaw: xburnBalanceRaw,
      xenApprovalRaw: xenApprovalRaw,
      xburnApprovalRaw: xburnApprovalRaw
    },
    stats,
    loadStats,
    account,
    loading: loadingNFTs || stats.loading,
    error: nftError || stats.error,
    xenPrice,     // Add price state
    xburnPrice,   // Add price state
    poolTvl,      // Add TVL state
    loadingPrices, // Add loading state
    priceError,    // Add error state
    fetchDexScreenerData, // Expose refetch function if needed
    externalStats
  };

  return (
    <GlobalDataContext.Provider value={value}>
      {children}
    </GlobalDataContext.Provider>
  );
};

export const useGlobalData = () => {
  const context = useContext(GlobalDataContext);
  if (!context) {
    throw new Error('useGlobalData must be used within a GlobalDataProvider');
  }
  return context;
}; 