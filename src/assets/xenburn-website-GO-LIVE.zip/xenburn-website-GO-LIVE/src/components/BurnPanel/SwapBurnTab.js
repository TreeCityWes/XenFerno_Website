import React, { useEffect } from 'react';
import FireParticles from '../FireParticles';
import { formatDecimals } from '../../utils/tokenUtils';
import { Tooltip } from '../../utils/components';

/**
 * SwapBurnTab - Component for the "Swap & Burn" tab content
 */
const SwapBurnTab = ({
  progress,
  isLoading,
  handleSwapAndBurn
}) => {
  // Debug logging for progress data
  useEffect(() => {
    console.log("SwapBurnTab progress:", progress);
    
    // Debug threshold detection
    if (progress && progress.accumulated && progress.threshold) {
      const accumulated = parseFloat(progress.accumulated);
      const threshold = parseFloat(progress.threshold);
      const percentage = (accumulated / threshold) * 100;
      const thresholdReached = accumulated >= (threshold * 0.999);
      
      console.log("Threshold detection:", {
        accumulated,
        threshold,
        percentage: percentage.toFixed(2) + "%",
        thresholdReached,
        rawPercentage: progress.percentage
      });
    }
  }, [progress]);

  // Calculate actual percentage (can be > 100)
  const getActualPercentage = () => {
    if (!progress || !progress.accumulated || !progress.threshold) {
      return 0;
    }
    const accumulated = parseFloat(progress.accumulated);
    const threshold = parseFloat(progress.threshold);
    if (threshold <= 0) return 0; // Avoid division by zero
    return (accumulated / threshold) * 100;
  };
  
  // Format progress percentage for display (no capping here)
  const formatProgress = () => {
    const actualPercentage = getActualPercentage();
    return `${Math.floor(actualPercentage)}%`; // Show floored percentage
  };

  // Calculate remaining cbXEN needed
  const calculateRemaining = () => {
    if (!progress || !progress.accumulated || !progress.threshold) {
      console.log("Missing accumulated or threshold values:", progress);
      return '0';
    }
    const accumulated = parseFloat(progress.accumulated);
    const threshold = parseFloat(progress.threshold);
    return formatDecimals(Math.max(0, threshold - accumulated), { useCommas: true });
  };

  // Calculate percentage for display
  const getPercentage = () => {
    if (!progress || !progress.accumulated || !progress.threshold) {
      return 0;
    }
    
    // Calculate percentage based on accumulated and threshold
    const accumulated = parseFloat(progress.accumulated);
    const threshold = parseFloat(progress.threshold);
    return Math.min(100, Math.max(0, (accumulated / threshold) * 100));
  };

  // Check if threshold is reached
  const isThresholdReached = () => {
    // Restored original logic:
    if (!progress || !progress.accumulated || !progress.threshold) {
      console.log("isThresholdReached: Missing progress data, returning false.");
      return false;
    }
    
    const accumulated = parseFloat(progress.accumulated);
    const threshold = parseFloat(progress.threshold);
    const comparisonValue = threshold * 0.999;
    const result = accumulated >= comparisonValue;

    // Log values used for comparison
    console.log(`isThresholdReached: accumulated=${accumulated}, threshold=${threshold}, comparisonValue=${comparisonValue}, result=${result}`);
    
    // Add some tolerance for floating point comparison
    // Consider it reached if it's at least 99.9% of the threshold
    // return accumulated >= (threshold * 0.999); // Original return
    return result; // Return calculated result
  };

  return (
    <div className="tab-content">
      <h2 className="burn-title swapBurn">Swap & Burn</h2>
      <p className="burn-subtitle">
        Swap accumulated cbXEN for XBURN when the 500,000,000 cbXEN threshold is reached
      </p>
      
      <div className="progress-container">
        <div className="progress-section-header">
          <h3>Accumulation Progress</h3>
          <Tooltip text="When the 500M cbXEN threshold is reached, anyone can trigger the Swap & Burn process to convert accumulated cbXEN to XBURN and burn it, reducing supply.">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="16" x2="12" y2="12"></line>
              <line x1="12" y1="8" x2="12.01" y2="8"></line>
            </svg>
          </Tooltip>
        </div>
        
        <div className="progress-info">
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${Math.min(100, getActualPercentage())}%` }}
            ></div>
          </div>
          
          <div className="progress-details">
            <div className="progress-percent">{formatProgress()}</div>
            <div className="accumulation-status">
              {progress && !isThresholdReached() ? (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
                </svg>
              ) : (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                  <polyline points="22 4 12 14.01 9 11.01" />
                </svg>
              )}
              <span>
                {progress && progress.accumulated && progress.threshold ? (
                  `${formatDecimals(progress.accumulated, { useCommas: true })} / ${formatDecimals(progress.threshold, { useCommas: true })} cbXEN`
                ) : (
                  'Loading...'
                )}
              </span>
            </div>
          </div>
        </div>
        
        <div className="accumulation-details">
          <div className="accumulation-row">
            <span className="accumulation-label">Accumulated cbXEN:</span>
            <span className="accumulation-value">
              {progress && progress.accumulated ? 
                formatDecimals(progress.accumulated, { useCommas: true }) : 
                'Loading...'}
            </span>
          </div>
          <div className="accumulation-row">
            <span className="accumulation-label">Threshold Required:</span>
            <span className="accumulation-value">
              {progress && progress.threshold ? 
                formatDecimals(progress.threshold, { useCommas: true }) : 
                'Loading...'}
            </span>
          </div>
          <div className="accumulation-row">
            <span className="accumulation-label">Remaining Needed:</span>
            <span className="accumulation-value">
              {calculateRemaining()} cbXEN
            </span>
          </div>
        </div>
        
        <div className="estimated-completion">
          {progress && isThresholdReached() ? (
            <span className="ready">Ready to Swap & Burn!</span>
          ) : (
            <span>
              {progress && progress.accumulated && progress.threshold ? (
                `${100 - Math.floor(getPercentage())}% remaining until the 500M cbXEN threshold is reached`
              ) : (
                'Calculating...'
              )}
            </span>
          )}
        </div>
        
        <div className="swap-burn-button-container">
          <div className="fire-effect" style={{ position: 'absolute', width: '100%', height: '100%' }}>
            <FireParticles width={300} height={100} intensity={0.3} isBackground={true} />
          </div>
          <button
            className="burn-button"
            onClick={handleSwapAndBurn}
            disabled={isLoading || !progress || !isThresholdReached()}
          >
            {isLoading ? (
              <div className="button-loading">
                <div className="loader"></div>
                <span>Processing Swap & Burn...</span>
              </div>
            ) : (
              'SWAP & BURN NOW'
            )}
          </button>
          
          {progress && !isThresholdReached() && (
            <div className="swap-disabled-reason">
              Swap & Burn will be enabled once the 500,000,000 cbXEN threshold is reached
            </div>
          )}
        </div>
        
        {progress && isThresholdReached() && (
          <div className="swap-info-note">
            <p>When you click the Swap & Burn button, the contract will:</p>
            <ol>
              <li>Swap the accumulated cbXEN for XBURN tokens</li>
              <li>Burn the received XBURN tokens</li>
              <li>Reset the accumulation counter for the next cycle</li>
            </ol>
            <p>This helps reduce the overall supply of XBURN tokens.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SwapBurnTab; 